package com.example.loginpage

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
